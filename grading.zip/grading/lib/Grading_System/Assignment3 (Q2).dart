String compressString(String input) {
  if (input.isEmpty) return input;

  StringBuffer compressed = StringBuffer();
  int count = 1;
  String currentChar = input[0];

  for (int i = 1; i < input.length; i++) {
    if (input[i] == currentChar) {
      count++;
    } else {
      compressed.write('$currentChar$count');
      currentChar = input[i];
      count = 1;
    }
  }
  compressed.write('$currentChar$count');

  String result = compressed.toString();
  return result.length < input.length ? result : input;
}

void main() {
  print(compressString("aaabbccccd")); // "a3b2c4d1"
  print(compressString("abcd"));       // "abcd" (returns original)
}