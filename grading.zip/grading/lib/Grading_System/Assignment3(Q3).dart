Map<String, int> sortMapByKeyLength(Map<String, int> inputMap) {
  var sortedEntries = inputMap.entries.toList()
    ..sort((a, b) => b.key.length.compareTo(a.key.length));

  return Map.fromEntries(sortedEntries);
}

void main() {
  Map<String, int> example = {
    'product123': 100,
    'item1': 50,
    'customer42': 200,
    'order': 75
  };

  print(sortMapByKeyLength(example));
  // {
  //   'customer42': 200,
  //   'product123': 100,
  //   'item1': 50,
  //   'order': 75
  // }
}