import 'dart:io';

void main() {
  // Get student's name
  stdout.write('Enter student\'s name: ');
  String? studentName = stdin.readLineSync();


  // Get marks for each subject
  double englishMarks =81;
  double mathsMarks = 75;
  double scienceMarks = 60;

  // Define credit hours
  const int englishCreditHours = 3;
  const int mathsCreditHours = 2;
  const int scienceCreditHours = 1;


  // Calculate total credit hours
  int totalCreditHours = englishCreditHours + mathsCreditHours + scienceCreditHours;

  //calculate GPA
  double GPA = ((englishMarks * englishCreditHours) +
      (mathsMarks * mathsCreditHours) +
      (scienceMarks * scienceCreditHours))/totalCreditHours;





  // Display results
  print('Student Name: $studentName');
  print('English Marks: $englishMarks');
  print('Maths Marks: $mathsMarks');
  print('Science Marks: $scienceMarks');
  print("GPA $GPA");

}