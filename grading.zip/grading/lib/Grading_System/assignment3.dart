List<int> flattenNestedList(List<dynamic> nestedList) {
  List<int> flatList = [];
  List<dynamic> stack = List.from(nestedList);

  while (stack.isNotEmpty) {
    var element = stack.removeLast();
    if (element is List) {
      stack.addAll(element.reversed);
    } else if (element is int) {
      flatList.add(element);
    }
  }

  return flatList.reversed.toList();
}

void main() {
  print(flattenNestedList([1, [2, 3], [4, [5, 6]]])); // [1, 2, 3, 4, 5, 6]
}